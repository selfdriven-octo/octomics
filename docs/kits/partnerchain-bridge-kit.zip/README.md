# PartnerChain Bridge Kit (Ouroboros)

This is a reference scaffold for a **Cardano-style side chain (Ouroboros-Praos)** with a **bridge** back to Cardano.
It includes:
- **Aiken** stubs for L1 Lockbox, L2 Bridge validator, and sAsset Minting Policy.
- A **Relayer** (Node.js) using **noble-ed25519** and **Ogmios WebSocket** subscriptions.
- A **docker-compose** that brings up: L1 node + Ogmios + Kupo, L2 node + Ogmios + Kupo, and the Relayer.

> ⚠️ You must provide real `config.json`, `topology.json`, `genesis.json`, `alonzo-genesis.json`, `conway-genesis.json` for both L1 and L2.
> The ones here are placeholders so the folders exist. Use your devnet or preprod configs on L1 and your PartnerChain genesis for L2.

## Quick Start

1. Place your **L1** configs into `./l1/config/` and **L2** configs into `./l2/config/`.
2. Put `attesters.json` in `./relayer/config/` and set `RELAYER_SK_HEX` in `docker-compose.yml`.
3. `docker compose up -d`
4. Deploy Aiken contracts (Lockbox on L1, Bridge+MintPolicy on L2) using your chosen flow.
5. Test the loop: **Lock on L1 → Mint sADA on L2**; **Burn on L2 → Unlock on L1**.

## Ports
- L1 node: 3001, Ogmios: 1337, Kupo: 1442
- L2 node: 4001, Ogmios: 2337, Kupo: 2442

## Aiken
Project is in `./aiken/`. Run:
```bash
cd aiken
aiken build
aiken check
```
