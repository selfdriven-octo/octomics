import { createHash } from "crypto";

export function blake2b256_hex(buf) {
  // Node doesn't have blake2b by default; for demo, use sha256 placeholder.
  // Replace with a real blake2b-256 (e.g. @noble/hashes) in production.
  return createHash("sha256").update(buf).digest("hex");
}

export function hexFromString(s) {
  return Buffer.from(s, "utf8").toString("hex");
}

export function msgToSign(domainHex, eventIdHex) {
  const domain = Buffer.from(domainHex, "hex");
  const eid = Buffer.from(eventIdHex, "hex");
  return Buffer.concat([domain, eid]);
}
