import { getLucid, ClaimDatumCodec } from "./lucid.js";
import { Data, Constr, toHex } from "lucid-cardano";

// ENV-required script info:
const CLAIM_SCRIPT_CBOR = process.env.CLAIM_SCRIPT_CBOR; // Plutus V2 script CBOR for optimistic validator
const CLAIM_SCRIPT_ADDRESS_L1 = process.env.CLAIM_SCRIPT_ADDRESS_L1;
const CLAIM_SCRIPT_ADDRESS_L2 = process.env.CLAIM_SCRIPT_ADDRESS_L2;

// Select script address by chain
function scriptAddress(chain) {
  return chain === "l1" ? CLAIM_SCRIPT_ADDRESS_L1 : CLAIM_SCRIPT_ADDRESS_L2;
}

export async function submitClaimTx(chain, direction, event, claim, bonds) {
  const lucid = await getLucid(chain === "l1" ? "l1" : "l2");
  const addr = scriptAddress(chain === "l1" ? "l1" : "l2");
  if (!addr) throw new Error("Missing CLAIM_SCRIPT_ADDRESS env for " + chain);
  const minAda = BigInt(2_000_000); // example ADA for script UTxO

  // Inline datum for claim UTxO
  const datum = ClaimDatumCodec({
    event_id: toHex(Buffer.from(claim.event_id, "hex")),
    msg: toHex(Buffer.from(claim.msg, "hex")),
    agg_sig: toHex(Buffer.from(claim.agg_sig, "hex")),
    attesters_root: toHex(Buffer.from(claim.attesters_root, "hex")),
    threshold: BigInt(claim.threshold),
    created_at_time_ms: BigInt(claim.created_at_time_ms),
    window_ms: BigInt(claim.window_ms),
    challenged: false,
    claimer_pkh: toHex(Buffer.from(bonds.claimer_pkh, "hex")),
    claimer_bond_lovelace: BigInt(claim.claimer_bond_lovelace),
    challenger_bond_lovelace: BigInt(claim.challenger_bond_lovelace),
    version: 1n
  });

  // NOTE: Our strict validator (scaffold) checks for an output to claimer_pkh with bond amount.
  // This example satisfies it by adding an extra PKH output for the bond.
  const pkhBondOut = { address: await lucid.wallet.address(), value: { lovelace: BigInt(claim.claimer_bond_lovelace) } };

  const tx = await lucid
    .newTx()
    .validFrom(claim.created_at_time_ms)
    .payToContract(addr, { inline: datum }, { lovelace: minAda })  // claim UTxO
    .payToAddress(pkhBondOut.address, pkhBondOut.value)            // bond to claimer (per scaffold)
    .complete();

  const signed = await tx.sign().complete();
  const txHash = await signed.submit();
  return txHash;
}

export async function submitFinalizeTx(chain, direction, claimRef) {
  const lucid = await getLucid(chain === "l1" ? "l1" : "l2");
  const addr = scriptAddress(chain === "l1" ? "l1" : "l2");
  if (!addr) throw new Error("Missing CLAIM_SCRIPT_ADDRESS env for " + chain);

  // Find the claim UTxO by datum field (event_id) via Kupo filter in production.
  // For illustration, fetch all at script and pick first.
  const utxos = await lucid.utxosAt(addr);
  if (utxos.length === 0) throw new Error("No claim UTxO found at script");

  const tx = await lucid
    .newTx()
    .collectFrom([utxos[0]], Data.void()) // use proper Finalize redeemer here
    .validFrom(claimRef.created_at_time_ms + claimRef.window_ms) // ensure after deadline
    .complete();

  const signed = await tx.sign().complete();
  const txHash = await signed.submit();
  return txHash;
}
