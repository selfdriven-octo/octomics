import { Lucid, Kupmios, Data, fromHex, toHex } from "lucid-cardano";

export async function getLucid(chain) {
  // chain: "l1" or "l2"
  const ogmios = process.env[chain.toUpperCase()+"_OGMIOS_URL"] || (chain === "l1" ? "ws://localhost:1337" : "ws://localhost:2337");
  const kupo = process.env[chain.toUpperCase()+"_KUPO_URL"] || (chain === "l1" ? "http://localhost:1442" : "http://localhost:2442");
  const networkId = Number(process.env[chain.toUpperCase()+"_NETWORK"] || 0); // 0=testnet (preprod/dev), 1=mainnet
  const kupmios = new Kupmios(ogmios, kupo);
  const lucid = await Lucid.new(kupmios, networkId === 1 ? "Mainnet" : "Preprod");
  const skHex = process.env[chain.toUpperCase()+"_PAYMENT_SK_HEX"];
  if (!skHex) throw new Error(`${chain} missing PAYMENT_SK_HEX`);
  lucid.selectWalletFromPrivateKey(skHex);
  return lucid;
}

// Minimal helpers for Plutus data enc/dec
export const ClaimDatumCodec = (d) => Data.to(d, ClaimDatumSchema);
export const ClaimRedeemer = (claimer_pkh) => Data.to({ constructor: 0, fields: [claimer_pkh] });
export const FinalizeRedeemer = () => Data.to({ constructor: 2, fields: [] });

// Aiken-like schema mirrored in JS (order matters).
// NOTE: This is illustrative; align constructors with your actual compiled Aiken artifacts.
export const ClaimDatumSchema = Data.Object({
  event_id: Data.Bytes(),
  msg: Data.Bytes(),
  agg_sig: Data.Bytes(),
  attesters_root: Data.Bytes(),
  threshold: Data.Integer(),
  created_at_time_ms: Data.Integer(),
  window_ms: Data.Integer(),
  challenged: Data.Boolean(),
  claimer_pkh: Data.Bytes(),
  claimer_bond_lovelace: Data.Integer(),
  challenger_bond_lovelace: Data.Integer(),
  version: Data.Integer(),
});
