# v6: Lucid CSL wiring for Claim & Finalize

This adds **Lucid**-based transaction builders and submitters that talk to your Ogmios+Kupo via **Kupmios**.

## Files
- `relayer/src/lucid.js` — Provider bootstrap and data schema for `ClaimDatum`
- `relayer/src/sdk-lucid.js` — `submitClaimTx` & `submitFinalizeTx` using Lucid
- `relayer/src/index-lucid.js` — Relayer loop that aggregates BLS, posts `Claim`, then `Finalize`

## Env required
- **Per chain (l1 / l2):**
  - `L1_OGMIOS_URL` / `L2_OGMIOS_URL` (default: ws://localhost:1337 / 2337)
  - `L1_KUPO_URL` / `L2_KUPO_URL` (default: http://localhost:1442 / 2442)
  - `L1_NETWORK` / `L2_NETWORK` (0=test, 1=mainnet)
  - `L1_PAYMENT_SK_HEX` / `L2_PAYMENT_SK_HEX` — bech32 or hex private keys accepted by Lucid
- **Bridge script:**
  - `CLAIM_SCRIPT_ADDRESS_L1` / `CLAIM_SCRIPT_ADDRESS_L2` — address of the optimistic claim validator
  - (Optionally) `CLAIM_SCRIPT_CBOR` if you want to attach reference script

- **Relayer:**
  - `DOMAIN_HEX` (domain separator, default `partner-bridge-v1`)
  - `WINDOW_MS`, `CLAIMER_BOND`, `CHALLENGER_BOND`
  - `AGG_BIN` path to Rust aggregator
  - `CLAIMER_PKH_HEX` — hex of the claimer payment key hash (scaffold)

## Run
```bash
cd relayer
npm i
node src/index-lucid.js
```

> NOTE: The Aiken validator scaffold currently checks that the **bond is paid to the claimer PKH**, which is not economically meaningful yet. Replace this with a script-locked bond in your production version (we kept it to align with the prior scaffold).

Wire Kupo queries to find the **exact claim UTxO** by `event_id` in production, and replace the simplified `utxosAt()` selection.
