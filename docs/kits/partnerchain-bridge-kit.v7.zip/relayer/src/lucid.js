import { Lucid, Kupmios, Data, fromHex, toHex } from "lucid-cardano";

export async function getLucid(tag) {
  const ogmios = process.env[tag.toUpperCase()+"_OGMIOS_URL"];
  const kupo = process.env[tag.toUpperCase()+"_KUPO_URL"];
  const networkId = Number(process.env[tag.toUpperCase()+"_NETWORK"] || 0);
  const kupmios = new Kupmios(ogmios || "ws://localhost:1337", kupo || "http://localhost:1442");
  const lucid = await Lucid.new(kupmios, networkId === 1 ? "Mainnet" : "Preprod");
  const skHex = process.env[tag.toUpperCase()+"_PAYMENT_SK_HEX"];
  if (!skHex) throw new Error(`${tag} missing PAYMENT_SK_HEX`);
  lucid.selectWalletFromPrivateKey(skHex);
  return lucid;
}

// ClaimDatum schema (strict version may differ; adjust to match compiled artifacts)
export const ClaimDatumSchema = Data.Object({
  event_id: Data.Bytes(),
  msg: Data.Bytes(),
  agg_sig: Data.Bytes(),
  attesters_root: Data.Bytes(),
  threshold: Data.Integer(),
  created_at_time_ms: Data.Integer(),
  window_ms: Data.Integer(),
  challenged: Data.Boolean(),
  claimer_pkh: Data.Bytes(),
  claimer_bond_lovelace: Data.Integer(),
  challenger_bond_lovelace: Data.Integer(),
  version: Data.Integer(),
});
export const ClaimDatumCodec = (d) => Data.to(d, ClaimDatumSchema);

// Escrow datum
export const EscrowDatumSchema = Data.Object({
  role: Data.Bytes(),
  claimer_pkh: Data.Bytes(),
  challenger_pkh: Data.Bytes(),
  event_id: Data.Bytes(),
  amount_lovelace: Data.Integer(),
  version: Data.Integer(),
});
export const EscrowDatumCodec = (d) => Data.to(d, EscrowDatumSchema);
