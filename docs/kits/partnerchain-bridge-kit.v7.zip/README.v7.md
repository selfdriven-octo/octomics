# v7: Bond Escrow script + Lucid escrow wiring + Kupo filtering scaffold

## New
- **Aiken bond-escrow validator**: `aiken_bond_escrow/validators/escrow.ak`
  - Two spend paths: `Finalize` (refund to claimer) and `ChallengeWin` (pay challenger).
  - Bind it to your claim by requiring a reference input to the finalized-claim UTxO.
- **Lucid SDK updates**:
  - `submitClaimTx` now **locks the claimer bond** at the escrow script (instead of sending to PKH).
  - `submitFinalizeTx` collects **both** the claim UTxO and the escrow UTxO to refund the claimer.
- **Kupo helper** (`relayer/src/kupo.js`):
  - Placeholder function `findClaimUtxoByEventId(...)` to fetch UTxOs and filter; replace with precise datum-based queries in production.

## Env additions
- `ESCROW_SCRIPT_ADDRESS_L1` / `ESCROW_SCRIPT_ADDRESS_L2`

## Next hardening
- On **Challenge**, create a challenger-bond escrow UTxO and a resolution path `ChallengeWin` to release challenger’s payout.
- Bind escrow spends to the finalized claim by checking a **reference input** (claim UTxO) whose datum matches `event_id` & role.
- Replace Kupo placeholder with exact **datum-field filtering** (or keep an indexed DB off-chain).
