
# Version 0.1 Runbook (Local Dev)

## 0) Prereqs
- Node 18+, `nargo` (Noir), Ogmios + Kupo pointed at a dev chain, Aiken if compiling validators.

## 1) Start verifier-service
```bash
cd verifier-service
cp .env.example .env
npm i
npm run dev         # listens on :8787
```

## 2) Build a stub proof
```bash
cd noir/partnerchain_praos_lc
cp witness.example.toml witness.toml
# fill fields
nargo check
nargo prove p --witness witness.toml   # creates proofs/p.proof
nargo verify p --proof proofs/p.proof  # sanity
```

## 3) Mint zk_ok UTxO (guarded by verifier)
```bash
cd relayer
npm i
export ZK_SCRIPT_ADDRESS_L1=addr_test1...
export L1_OGMIOS_URL=ws://localhost:1337
export L1_KUPO_URL=http://localhost:1442
export L1_NETWORK=0
export L1_PAYMENT_SK_HEX=<hex>
export VERIFIER_URL=http://localhost:8787/verify

node src/create-zk-utxo.js <event_id_hex> <epoch> ../noir/partnerchain_praos_lc/proofs/p.proof
```

## 4) Finalize with ZK on-chain
Use your v11 **Lucid SDK** `submitFinalizeTx(..., { zk: true })` — it will read the proof UTxO.

## 5) Next steps
- Replace the Noir circuit with VRF + header checks.
- Harden verifier-service (validate public inputs, auth, logs).
- Wire full Aiken validators from v11 (or your fork), deploy script addresses, and iterate.
