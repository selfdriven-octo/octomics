
# Verifier Service (v0.1)

A tiny HTTP service that shells out to `nargo verify` for your Noir proof.
- **Input**: `POST /verify` with `{ event_id_hex, epoch, proof_path }`
- **Output**: `{ ok: true, ... }` if `nargo verify` succeeds.

> WARNING: This is for **dev** only. For production, embed/compile a verifier, validate public inputs, and authenticate callers.
