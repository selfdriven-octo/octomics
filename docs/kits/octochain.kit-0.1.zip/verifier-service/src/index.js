
import express from "express";
import { spawn } from "child_process";
import path from "path";
import fs from "fs";

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 8787;
const NOIR_DIR = process.env.NOIR_PROJECT_DIR || "../noir/partnerchain_praos_lc";

function run(cmd, args, cwd) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { cwd, stdio: ["ignore", "pipe", "pipe"] });
    let out = "", err = "";
    p.stdout.on("data", d => (out += d.toString()));
    p.stderr.on("data", d => (err += d.toString()));
    p.on("close", code => {
      if (code !== 0) return reject(new Error(err || `exit ${code}`));
      resolve(out.trim());
    });
  });
}

// POST /verify { event_id_hex, epoch, proof_path? }
app.post("/verify", async (req, res) => {
  try {
    const { event_id_hex, epoch, proof_path } = req.body || {};
    if (!event_id_hex) throw new Error("event_id_hex required");
    // In a real service you'd parse/verify public inputs from proof. Here we shell out to nargo verify.
    const pf = proof_path || path.join(NOIR_DIR, "proofs/p.proof");
    if (!fs.existsSync(pf)) throw new Error("Proof file not found: " + pf);
    await run("nargo", ["verify", "p", "--proof", pf], NOIR_DIR);
    res.json({ ok: true, event_id_hex, epoch: Number(epoch||0) });
  } catch (e) {
    res.status(400).json({ ok: false, error: String(e.message || e) });
  }
});

app.listen(PORT, () => console.log(`[verifier] listening on :${PORT}`));
