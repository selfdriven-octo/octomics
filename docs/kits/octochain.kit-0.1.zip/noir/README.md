
# Noir Praos LC (v0.1, stub)

- Outline circuit with public inputs for `(event_id, epoch, header_hash, parent_hash, slot, vrf_*)`.
- Constraints are placeholders — swap in Poseidon and a concrete VRF gadget when ready.

## Commands
```bash
cd noir/partnerchain_praos_lc
nargo check
nargo prove p --witness witness.toml   # produces proofs/p.proof
nargo verify p --proof proofs/p.proof
```
