
// v0.1: Create zk_ok UTxO only if the verifier-service confirms proof validity.
import { Lucid, Kupmios, Data } from "lucid-cardano";

const ZK_SCRIPT_ADDRESS = process.env.ZK_SCRIPT_ADDRESS_L1 || process.env.ZK_SCRIPT_ADDRESS_L2;
const OGMIOS = process.env.L1_OGMIOS_URL || "ws://localhost:1337";
const KUPO = process.env.L1_KUPO_URL || "http://localhost:1442";
const NETWORK = Number(process.env.L1_NETWORK || 0);
const PAYMENT_SK = process.env.L1_PAYMENT_SK_HEX;
const VERIFIER_URL = process.env.VERIFIER_URL || "http://localhost:8787/verify";

const ZkDatum = Data.Object({ event_id: Data.Bytes(), epoch: Data.Integer(), ok: Data.Boolean() });

async function verifyProof(event_id_hex, epoch, proof_path){
  const res = await fetch(VERIFIER_URL, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ event_id_hex, epoch, proof_path })
  });
  if(!res.ok) {
    const j = await res.json().catch(()=>({}));
    throw new Error(`verifier not ok: ${res.status} ${j.error||""}`);
  }
  const j = await res.json();
  if(!j.ok) throw new Error("verifier declined proof");
  return true;
}

async function main(){
  if(!ZK_SCRIPT_ADDRESS) throw new Error("ZK_SCRIPT_ADDRESS_* env required");
  if(!PAYMENT_SK) throw new Error("L1_PAYMENT_SK_HEX required");
  const eventIdHex = process.argv[2]; // 64 hex bytes
  const epoch = BigInt(process.argv[3] || "0");
  const proofPath = process.argv[4] || "noir/partnerchain_praos_lc/proofs/p.proof";

  await verifyProof(eventIdHex, Number(epoch), proofPath);

  const kupmios = new Kupmios(OGMIOS, KUPO);
  const lucid = await Lucid.new(kupmios, NETWORK===1?"Mainnet":"Preprod");
  lucid.selectWalletFromPrivateKey(PAYMENT_SK);

  const datum = Data.to({ event_id: eventIdHex, epoch, ok: true }, ZkDatum);
  const tx = await lucid.newTx()
    .payToContract(ZK_SCRIPT_ADDRESS, { inline: datum }, { lovelace: 2_000_000n })
    .complete();
  const signed = await tx.sign().complete();
  const txHash = await signed.submit();
  console.log("zk_ok utxo minted tx:", txHash);
}

main().catch(e=>{ console.error(e); process.exit(1); });
