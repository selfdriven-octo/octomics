
# Relayer utils (v0.1)

This repo includes a helper to **mint a ZK-ok UTxO** only if an external verifier says the proof is valid.

## Usage
```bash
export ZK_SCRIPT_ADDRESS_L1=addr_test1...
export L1_OGMIOS_URL=ws://localhost:1337
export L1_KUPO_URL=http://localhost:1442
export L1_NETWORK=0
export L1_PAYMENT_SK_HEX=<hex>

# Verifier service URL
export VERIFIER_URL=http://localhost:8787/verify

node src/create-zk-utxo.js <event_id_hex> <epoch> noir/partnerchain_praos_lc/proofs/p.proof
```
