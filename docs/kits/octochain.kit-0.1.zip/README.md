
# PartnerChain Bridge Kit — Version 0.1

This is a **testable** starter bundle that ties together:
- **On-chain Aiken validators** (claim + escrow + zk gate) — see v11.
- **Lucid SDK** submitters (claim/challenge/finalize/challenge-win) — see v10/v11.
- **Noir circuit (stub)** + **Verifier Service** that only creates a zk_ok UTxO when a proof verifies.
- A CLI flow you can run locally to exercise the path end-to-end on a devnet.

> This v0.1 focuses on *operational testing*. Cryptographic circuits are stubs you can iteratively replace.
