
# v11: from_data decoding + Aiken tests + ZK-gated Finalize (time OR proof)

## Aiken
- Claim validator: decodes inline datums with `from_data`, enforces re-output on `Challenge`, and accepts `Finalize` either **after deadline** or with a **ZK verifier reference**.
- Escrow validator: decodes reference **ClaimDatum** and gates payouts on `challenged` flag.
- ZK verifier (dummy): `aiken_zk_verifier/validators/zk_ok.ak` to carry `ZkDatum(event_id, epoch, ok)`.

## Tests
- Aiken test stubs included (expand to full Tx contexts).
- JS test (`relayer/tests/datum_redeemer.test.mjs`) confirms datum roundtrip + redeemer encodings.

## Lucid SDK
- `submitFinalizeTx(..., { zk: true })` reads a ZK proof UTxO (address via `ZK_SCRIPT_ADDRESS_*`) instead of relying on the time window.

## Kupo helpers
- Decode inline datum CBOR to pick exact Claim/Escrow UTxOs by `event_id` (+ `role` for escrow), plus a simple ZK proof finder.

