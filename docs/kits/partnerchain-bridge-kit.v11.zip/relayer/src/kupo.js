import { ClaimDatumFrom, EscrowDatumFrom } from "./lucid.js";
export async function utxosAt(kupoUrl, address) {
  const res = await fetch(`${kupoUrl}/v1/utxo/${address}`);
  if (!res.ok) throw new Error(`Kupo ${res.status}`);
  return res.json();
}
export function extractInlineDatumCbor(utxo) {
  if (utxo?.inline_datum?.cbor) return utxo.inline_datum.cbor;
  if (utxo?.datum?.inline?.cborHex) return utxo.datum.inline.cborHex;
  if (utxo?.datum?.cbor) return utxo.datum.cbor;
  return null;
}
export async function findClaimUtxoByEventId(kupoUrl, address, eventIdHex) {
  const utxos = await utxosAt(kupoUrl, address);
  for (const u of utxos) {
    const cbor = extractInlineDatumCbor(u);
    if (!cbor) continue;
    try {
      const d = ClaimDatumFrom(cbor);
      if ((d.event_id||"").toLowerCase() === eventIdHex.toLowerCase()) return u;
    } catch {}
  }
  return null;
}
export async function findEscrowUtxo(kupoUrl, address, roleStr, eventIdHex) {
  const utxos = await utxosAt(kupoUrl, address);
  const roleHex = Buffer.from(roleStr, "utf8").toString("hex");
  for (const u of utxos) {
    const cbor = extractInlineDatumCbor(u);
    if (!cbor) continue;
    try {
      const d = EscrowDatumFrom(cbor);
      if ((d.role||"").toLowerCase() === roleHex.toLowerCase()
       && (d.event_id||"").toLowerCase() === eventIdHex.toLowerCase()) return u;
    } catch {}
  }
  return null;
}
export async function findZkProofUtxo(kupoUrl, address, eventIdHex) {
  const utxos = await utxosAt(kupoUrl, address);
  for (const u of utxos) {
    const cbor = extractInlineDatumCbor(u);
    if (!cbor) continue;
    if (cbor.toLowerCase().includes(eventIdHex.toLowerCase())) return u;
  }
  return null;
}
