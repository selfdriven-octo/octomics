import { getLucid, ClaimDatumCodec, EscrowDatumCodec, RedeemerClaim, RedeemerEscrow } from "./lucid.js";
import { toHex } from "lucid-cardano";
import { findClaimUtxoByEventId, findEscrowUtxo, findZkProofUtxo } from "./kupo.js";

const CLAIM_SCRIPT_ADDRESS_L1 = process.env.CLAIM_SCRIPT_ADDRESS_L1;
const CLAIM_SCRIPT_ADDRESS_L2 = process.env.CLAIM_SCRIPT_ADDRESS_L2;
const ESCROW_SCRIPT_ADDRESS_L1 = process.env.ESCROW_SCRIPT_ADDRESS_L1;
const ESCROW_SCRIPT_ADDRESS_L2 = process.env.ESCROW_SCRIPT_ADDRESS_L2;
const ZK_SCRIPT_ADDRESS_L1 = process.env.ZK_SCRIPT_ADDRESS_L1;
const ZK_SCRIPT_ADDRESS_L2 = process.env.ZK_SCRIPT_ADDRESS_L2;

function claimScript(tag){ return tag === "l1" ? CLAIM_SCRIPT_ADDRESS_L1 : CLAIM_SCRIPT_ADDRESS_L2; }
function escrowScript(tag){ return tag === "l1" ? ESCROW_SCRIPT_ADDRESS_L1 : ESCROW_SCRIPT_ADDRESS_L2; }
function zkScript(tag){ return tag === "l1" ? ZK_SCRIPT_ADDRESS_L1 : ZK_SCRIPT_ADDRESS_L2; }

export async function submitFinalizeTx(chain, direction, ref, opts = {}) {
  const tag = chain === "l1" ? "l1" : "l2";
  const lucid = await getLucid(tag);
  const claimAddr = claimScript(tag);
  const escrowAddr = escrowScript(tag);
  const zkAddr = zkScript(tag);
  const kupoUrl = process.env[tag.toUpperCase()+"_KUPO_URL"] || (tag === "l1" ? "http://localhost:1442" : "http://localhost:2442");

  const claimUtxo = await findClaimUtxoByEventId(kupoUrl, claimAddr, ref.event_id);
  if(!claimUtxo) throw new Error("Claim UTxO not found");

  const claimerEscrow = await findEscrowUtxo(kupoUrl, escrowAddr, "CLAIMER_BOND", ref.event_id);
  if(!claimerEscrow) throw new Error("Claimer escrow not found");

  const txb = lucid.newTx()
    .collectFrom([claimUtxo], RedeemerClaim.Finalize())
    .collectFrom([claimerEscrow], RedeemerEscrow.Finalize())
    .readFrom([claimUtxo]);
  if (opts.zk && zkAddr) {
    const zk = await findZkProofUtxo(kupoUrl, zkAddr, ref.event_id);
    if (!zk) throw new Error("ZK proof UTxO not found");
    txb.readFrom([zk]);
  } else {
    txb.validFrom(ref.created_at_time_ms + ref.window_ms);
  }
  const tx = await txb.complete();
  const signed = await tx.sign().complete();
  return await signed.submit();
}
