import { Data, toHex, fromHex, Constr } from "lucid-cardano";
import { ClaimDatumSchema, EscrowDatumSchema, RedeemerClaim, RedeemerEscrow } from "../src/lucid.js";

const hex = (s)=>Buffer.from(s,"utf8").toString("hex");
const sampleClaim = {
  event_id: hex("event123"),
  msg: hex("domain||event123"),
  agg_sig: hex("agg"),
  attesters_root: hex("root"),
  threshold: 2n,
  created_at_time_ms: 1000n,
  window_ms: 60000n,
  challenged: false,
  claimer_pkh: hex("claimer"),
  claimer_bond_lovelace: 2000000n,
  challenger_bond_lovelace: 2000000n,
  version: 1n,
};
const enc = Data.to(sampleClaim, ClaimDatumSchema);
const dec = Data.from(enc, ClaimDatumSchema);
console.log("claim roundtrip ok:", JSON.stringify(dec) === JSON.stringify(sampleClaim));
console.log("redeemer claim len:", RedeemerClaim.Claim(hex("claimer")).length);
console.log("redeemer challenge len:", RedeemerClaim.Challenge(hex("challenger"), hex("reason")).length);
console.log("redeemer finalize len:", RedeemerClaim.Finalize().length);
console.log("escrow finalize len:", RedeemerEscrow.Finalize().length);
console.log("escrow challengewin len:", RedeemerEscrow.ChallengeWin().length);
