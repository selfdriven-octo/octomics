import { blake2b } from "@noble/hashes/blake2b";
export function blake2b256_hex(buf) {
  const out = blake2b(buf, { dkLen: 32 });
  return Buffer.from(out).toString("hex");
}
export function msgToSign(domainHex, eventIdHex) {
  const domain = Buffer.from(domainHex, "hex");
  const eid = Buffer.from(eventIdHex, "hex");
  return Buffer.concat([domain, eid]);
}
