import { subscribe } from "./ogmios.js";
import { blake2b256_hex, msgToSign } from "./util.js";
import { submitTx, buildClaimTx, buildFinalizeTx } from "./sdk.js";
import { spawn } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";

const L1_OGMIOS = process.env.L1_OGMIOS || "ws://localhost:1337";
const L2_OGMIOS = process.env.L2_OGMIOS || "ws://localhost:2337";
const DOMAIN_HEX = process.env.DOMAIN_HEX || "706172746e65722d6272696467652d7631"; // "partner-bridge-v1"
const WINDOW_MS = parseInt(process.env.WINDOW_MS || "1800000", 10);
const AGG_BIN = process.env.AGG_BIN || "./aggregator/target/release/partnerchain-aggregator";
const BONDS = { claimer: parseInt(process.env.CLAIMER_BOND || "2000000", 10), challenger: parseInt(process.env.CHALLENGER_BOND || "2000000", 10) };

function collectPartialsForEvent(_event) {
  return [
    { pk_g1: "hex_pubkey_1", sig_g2: "hex_sig_1" },
    { pk_g1: "hex_pubkey_2", sig_g2: "hex_sig_2" }
  ];
}

function mkEventId(e) {
  const buf = Buffer.concat([
    Buffer.from(e.networkId || "l1"),
    Buffer.from(e.direction || "LOCK"),
    Buffer.from(e.txId || "", "hex"),
    Buffer.from([e.txIndex || 0]),
    Buffer.from(e.assetPolicy || "", "hex"),
    Buffer.from(e.assetName || ""),
    Buffer.from(String(e.amount || 0)),
    Buffer.from(e.sender || ""),
    Buffer.from(e.recipient || ""),
    Buffer.from(String(e.epoch || 0)),
    Buffer.from(String(e.nonce || 0)),
  ]);
  return blake2b256_hex(buf);
}

function runAggregator(partials) {
  const tmp = path.join(os.tmpdir(), `partials-${Date.now()}.json`);
  fs.writeFileSync(tmp, JSON.stringify(partials));
  return new Promise((resolve, reject) => {
    const p = spawn(AGG_BIN, ["--input", tmp], { stdio: ["ignore", "pipe", "inherit"] });
    let out = "";
    p.stdout.on("data", (d) => { out += d.toString(); });
    p.on("close", (code) => {
      fs.unlinkSync(tmp);
      if (code !== 0) return reject(new Error("aggregator exit code " + code));
      try { resolve(JSON.parse(out)); } catch (e) { reject(e); }
    });
  });
}

const scheduled = new Map();

async function postClaim(chain, direction, event) {
  const id = mkEventId(event);
  const msg = msgToSign(DOMAIN_HEX, id);
  const partials = collectPartialsForEvent(event);
  const agg = await runAggregator(partials);
  const nowMs = Date.now();
  const claim = {
    event_id: id,
    msg: Buffer.from(msg).toString("hex"),
    agg_sig: agg.agg_sig_g2,
    attesters_root: agg.agg_hash,
    threshold: partials.length, // TODO: set to K
    created_at_time_ms: nowMs,
    window_ms: WINDOW_MS,
    claimer_bond_lovelace: BONDS.claimer,
    challenger_bond_lovelace: BONDS.challenger
  };
  const bonds = { claimer_pkh: "replace_with_claimer_pkh" };
  const tx = buildClaimTx(direction, event, claim, bonds);
  await submitTx(chain, tx);
  if (!scheduled.has(id)) {
    const t = setTimeout(async () => {
      try {
        const fin = buildFinalizeTx(direction, { event_id: id });
        await submitTx(chain, fin);
      } catch (e) { console.error("[relayer] finalize error", e.message); }
      finally { scheduled.delete(id); }
    }, WINDOW_MS + 5000);
    scheduled.set(id, t);
  }
}

async function handleLock(lockEvent) { await postClaim("l2", "L2_FROM_L1_LOCK", lockEvent); }
async function handleBurn(burnEvent) { await postClaim("l1", "L1_FROM_L2_BURN", burnEvent); }

function start() {
  subscribe(L1_OGMIOS, (msg) => { if (msg && msg.lockEvent) handleLock(msg.lockEvent); });
  subscribe(L2_OGMIOS, (msg) => { if (msg && msg.burnEvent) handleBurn(msg.burnEvent); });
  console.log("[relayer v5] started (strict bonds + auto finalize)");
}
start();
