export async function submitTx(chain, tx) {
  console.log(`[sdk] (${chain}) submit ${tx.kind}:`, tx.raw.slice(0, 96), "...");
}
export function buildClaimTx(direction, event, claim, bonds) {
  return { kind: "CLAIM_TX", raw: JSON.stringify({ direction, event, claim, bonds }) };
}
export function buildFinalizeTx(direction, claimRef) {
  return { kind: "FINALIZE_TX", raw: JSON.stringify({ direction, claimRef }) };
}
