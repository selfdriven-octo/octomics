import WebSocket from "ws";
export function subscribe(url, onMsg) {
  const ws = new WebSocket(url);
  ws.on("open", () => console.log("[ogmios] connected", url));
  ws.on("message", (raw) => { try { onMsg(JSON.parse(raw.toString())); } catch {} });
  ws.on("close", () => console.log("[ogmios] closed", url));
  ws.on("error", (e) => console.error("[ogmios] error:", e.message));
  return ws;
}
