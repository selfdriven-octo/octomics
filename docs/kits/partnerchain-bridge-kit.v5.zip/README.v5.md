# v5: Strict bonds + time window (Aiken) & Node wrapper for Rust aggregator

## Aiken
- Module: `aiken_optimistic_bonds_strict/validators/optimistic_bridge_bonds_strict.ak`
- Enforces:
  - exact lovelace for **claimer**/**challenger** bonds
  - `Claim`: tx.lower_bound >= created_at_time_ms
  - `Challenge`: tx.upper_bound <= (created_at_time_ms + window_ms)
  - `Finalize`: tx.lower_bound >= (created_at_time_ms + window_ms) and `challenged == False`
- Use as a **reference input** guard for your Lockbox/Bridge spend.

## Relayer
- `relayer/src/index.js` shells to Rust aggregator (`AGG_BIN`) to produce `agg_sig_g2`.
- Posts `Claim`, then auto-posts `Finalize` after `WINDOW_MS` (+5s).
- Env: `WINDOW_MS`, `CLAIMER_BOND`, `CHALLENGER_BOND`, `AGG_BIN`

## Build aggregator
```bash
(cd aggregator && cargo build --release)
```

Wire claim/finalize into your actual tx-builders (CSL + Ogmios TxSubmission).
