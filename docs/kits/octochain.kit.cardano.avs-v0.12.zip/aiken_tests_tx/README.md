
# Aiken state-machine tests (scaffold)

These tests sketch how to assemble Tx contexts for:
1) Claim -> Finalize (time path)
2) Claim -> Challenge -> ChallengeWin
3) Claim -> Finalize (ZK path, no time window)

Port these into your Aiken projects (`aiken test`), replacing `TODO` with actual context builders.
