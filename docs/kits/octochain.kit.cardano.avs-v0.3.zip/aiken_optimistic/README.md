Optimistic bridge validator skeleton with claim/challenge/finalize.
