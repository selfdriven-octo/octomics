Noir skeleton for Praos light client proof.
