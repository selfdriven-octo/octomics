v3 kit: optimistic bridge, BLS aggregator scaffold, Noir circuit skeleton.
