export async function submitTx(c,t){console.log("submit",c,t.kind)}
export function buildClaimTx(){return {kind:"CLAIM_TX"}}
export function buildFinalizeTx(){return {kind:"FINALIZE_TX"}}
