export async function utxosAt(kupoUrl, address) {
  const res = await fetch(`${kupoUrl}/v1/utxo/${address}`);
  if (!res.ok) throw new Error(`Kupo ${res.status}`);
  return res.json();
}

export async function findUtxoByPredicate(kupoUrl, address, predicate) {
  const utxos = await utxosAt(kupoUrl, address);
  for (const u of utxos) {
    if (await predicate(u)) return u;
  }
  return null;
}

export async function findClaimUtxoByEventId(kupoUrl, scriptAddress, eventIdHex) {
  return await findUtxoByPredicate(kupoUrl, scriptAddress, async (u) => {
    // TODO: decode inline datum CBOR to get event_id, compare to eventIdHex.
    // Placeholder: return first.
    return true;
  });
}
