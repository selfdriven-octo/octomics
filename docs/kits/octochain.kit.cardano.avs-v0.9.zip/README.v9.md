# v9: Datum-checked Challenge & reference-claim escrow gating + ChallengeWin submitter

## Aiken
- **Claim validator**
  - On `Challenge`, it now **inspects the re-output's inline datum** and checks it equals the original datum with only `challenged` flipped to `true`.
  - (Scaffold) `decode_claim_datum` is a placeholder; in your compiled Aiken project you’ll use `from_data` for `ClaimDatum` to decode the inline datum.
- **Escrow validator**
  - Requires a **reference input** to the claim UTxO and (scaffold) `ref_claim_matches(...)` ensures the event_id and challenge status match the spend path.

## Lucid SDK
- `submitChallengeTx(...)`: consumes the claim, re-creates it with `challenged=true`, and locks the **challenger bond** escrow.
- `submitChallengeWinTx(...)`: spends the **challenger escrow** with `ChallengeWin`, using the **claim as reference**.
- `submitFinalizeTx(...)`: collects claim + **claimer escrow** and passes the claim as a reference input to the escrow script.

## Kupo helper
- Added `findUtxoByPredicate(...)` to support smarter selection (decode inline datums to match `event_id` in your production wiring).

## Final touches you should do before shipping
- Replace all `Data.void()` redeemers with properly encoded redeemers (`Claim`, `Challenge{...}`, `Finalize`, `ChallengeWin`) that match your Aiken constructors.
- Implement datum decoding both in **Aiken** (`from_data`) and in **relayer (JS)** to filter UTxOs by `event_id` precisely.
- Extend escrow to differentiate roles (claimer vs challenger) by parsing its inline datum on-chain and selecting the right UTxO on the client.
