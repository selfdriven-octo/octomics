import { subscribe } from "./ogmios.js";
import { blake2b256_hex, msgToSign } from "./util.js";
import { sign, toBitmap } from "./threshold.js";
import { buildMintTxFromLock, buildUnlockTxFromBurn, submitTx } from "./sdk.js";
import fs from "fs";

const L1_OGMIOS = process.env.L1_OGMIOS || "ws://localhost:1337";
const L2_OGMIOS = process.env.L2_OGMIOS || "ws://localhost:2337";
const RELAYER_SK_HEX = process.env.RELAYER_SK_HEX || "";
const DOMAIN_HEX = process.env.DOMAIN_HEX || "706172746e65722d6272696467652d7631"; // "partner-bridge-v1"
const ATTESTERS_PATH = process.env.ATTESTERS_JSON || "/config/attesters.json";

const attesters = JSON.parse(fs.readFileSync(ATTESTERS_PATH, "utf8"));
const PUBKEYS = attesters.pubkeys;
const K = parseInt(process.env.THRESHOLD_K || attesters.thresholdK || "2", 10);

// Simple in-memory de-dupe
const seen = new Set();

function mkEventId(e) {
  const buf = Buffer.concat([
    Buffer.from(e.networkId || "l1"),
    Buffer.from(e.direction || "LOCK"),
    Buffer.from(e.txId || "", "hex"),
    Buffer.from([e.txIndex || 0]),
    Buffer.from(e.assetPolicy || "", "hex"),
    Buffer.from(e.assetName || ""),
    Buffer.from(String(e.amount || 0)),
    Buffer.from(e.sender || ""),
    Buffer.from(e.recipient || ""),
    Buffer.from(String(e.epoch || 0)),
    Buffer.from(String(e.nonce || 0)),
  ]);
  return blake2b256_hex(buf); // replace with real blake2b-256
}

async function handleLock(e) {
  const id = mkEventId(e);
  if (seen.has(id)) return;
  seen.add(id);
  const msg = msgToSign(DOMAIN_HEX, id);
  const sig = await sign(RELAYER_SK_HEX, msg);
  const bitmap = toBitmap([0], PUBKEYS.length); // this node is index 0 by convention
  const sigsBundle = { id, sigs: [sig], bitmap: Buffer.from(bitmap).toString("hex") };
  const tx = buildMintTxFromLock(e, sigsBundle);
  await submitTx("l2", tx);
}

async function handleBurn(e) {
  const id = mkEventId(e);
  if (seen.has(id)) return;
  seen.add(id);
  const msg = msgToSign(DOMAIN_HEX, id);
  const sig = await sign(RELAYER_SK_HEX, msg);
  const bitmap = toBitmap([0], PUBKEYS.length);
  const sigsBundle = { id, sigs: [sig], bitmap: Buffer.from(bitmap).toString("hex") };
  const tx = buildUnlockTxFromBurn(e, sigsBundle);
  await submitTx("l1", tx);
}

function start() {
  subscribe(L1_OGMIOS, (msg) => {
    // TODO: decode Lock events from actual Ogmios messages / Kupo queries.
    // Here we simulate by looking for a made-up "lockEvent" field.
    if (msg && msg.lockEvent) handleLock(msg.lockEvent);
  });
  subscribe(L2_OGMIOS, (msg) => {
    // TODO: decode Burn events.
    if (msg && msg.burnEvent) handleBurn(msg.burnEvent);
  });
  console.log("[relayer] started", { L1_OGMIOS, L2_OGMIOS, K });
}

start();
