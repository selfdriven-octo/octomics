import * as ed from "noble-ed25519";

export async function sign(skHex, msgBytes) {
  const sk = skHex.startsWith("0x") ? skHex.slice(2) : skHex;
  // noble-ed25519 expects 32-byte private key; use RFC8032 style.
  const sig = await ed.sign(msgBytes, sk);
  return Buffer.from(sig).toString("hex");
}

export async function verifyMany(pubkeysHex, msgBytes, sigsHex, bitmap, k) {
  let okCount = 0;
  for (let i = 0; i < pubkeysHex.length; i++) {
    const bit = (bitmap[i >> 3] >> (i & 7)) & 1;
    if (!bit) continue;
    const pkHex = pubkeysHex[i];
    const sigHex = sigsHex[i];
    if (!sigHex) continue;
    const valid = await ed.verify(sigHex, msgBytes, pkHex);
    if (valid) okCount++;
  }
  return okCount >= k;
}

export function toBitmap(indexes, n) {
  const bytes = new Uint8Array(Math.ceil(n / 8));
  for (const idx of indexes) {
    const b = idx >> 3, bit = idx & 7;
    bytes[b] |= (1 << bit);
  }
  return bytes;
}
