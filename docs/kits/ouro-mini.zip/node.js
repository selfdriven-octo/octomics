
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createServer, connectToPeers, broadcast, send } = require('./lib/network');
const { makeGenesis, forgeBlock, validateBlock, isEligible, thresholdFor, MAX256 } = require('./lib/consensus');
const { sha256_hex } = require('./lib/block');

// --- CLI args (CommonJS) ---
const args = process.argv.slice(2);
function getArg(name, def) {
  const i = args.indexOf(`--${name}`);
  if (i >= 0 && i + 1 < args.length) return args[i+1];
  return def;
}

const PORT     = parseInt(getArg('port', '4001'), 10);
const NAME     = getArg('name', `N${PORT}`);
const STAKE    = parseInt(getArg('stake', '500'), 10);
const PEERS    = (getArg('peers', '') || '').split(',').map(s => s.trim()).filter(Boolean);
const SLOT_MS  = parseInt(getArg('slotMs', '2000'), 10);
const F_ACTIVE = parseFloat(getArg('f', '0.5')); // active slot coefficient (0,1]

// Persistence paths
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
const NODE_DIR = path.join(DATA_DIR, `port-${PORT}`);
if (!fs.existsSync(NODE_DIR)) fs.mkdirSync(NODE_DIR);
const KEYS_FILE = path.join(NODE_DIR, 'keys.json');
const CHAIN_FILE = path.join(NODE_DIR, 'chain.json');

function saveJSON(file, obj) { fs.writeFileSync(file, JSON.stringify(obj, null, 2)); }
function loadJSON(file, def) { try { return JSON.parse(fs.readFileSync(file)); } catch { return def; } }

// Key management (Ed25519)
function ensureKeys() {
  if (fs.existsSync(KEYS_FILE)) return loadJSON(KEYS_FILE, null);
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const pubPem = publicKey.export({ type: 'spki', format: 'pem' });
  const privPem = privateKey.export({ type: 'pkcs8', format: 'pem' });
  const keys = { publicKeyPem: pubPem, privateKeyPem: privPem };
  saveJSON(KEYS_FILE, keys);
  return keys;
}

// Load or init chain
function ensureChain() {
  if (fs.existsSync(CHAIN_FILE)) return loadJSON(CHAIN_FILE, null);
  const genesis = makeGenesis();
  const chain = [genesis];
  saveJSON(CHAIN_FILE, chain);
  return chain;
}

let keys = ensureKeys();
let chain = ensureChain();
let height = chain.length - 1;

// Total stake is sum of known stakes (including ours). For demo, we infer two-node total if peers known.
let TOTAL_STAKE = STAKE + 500; // default guess for demo
// Allow override from CLI for total stake if needed
const totalStakeOverride = getArg('totalStake', '');
if (totalStakeOverride) TOTAL_STAKE = parseInt(totalStakeOverride, 10);

// --- Networking ---
const wss = createServer(PORT, (msg, ws) => {
  handleMessage(msg, ws);
});
const sockets = connectToPeers(PEERS, (ws, url) => {
  // send tip on connect
  send(ws, { type: 'hello', name: NAME, port: PORT, stake: STAKE, pubkey: keys.publicKeyPem });
  send(ws, { type: 'tip', height, hash: chain[chain.length-1].hash });
}, (msg, ws, url) => {
  handleMessage(msg, ws);
});

const peers = new Map(); // url -> {name, stake, pubkey}

function handleMessage(msg, ws) {
  switch (msg.type) {
    case 'hello':
      // remember peer stake/public key
      if (msg.name) {
        peers.set(msg.name, { stake: msg.stake||0, pubkey: msg.pubkey||'' });
        // Recompute TOTAL_STAKE as our stake + sum peer stakes
        let sum = STAKE;
        for (const [,p] of peers) sum += (p.stake||0);
        TOTAL_STAKE = sum;
      }
      break;
    case 'tip':
      // Request sync if remote is ahead
      if (msg.height > height) {
        broadcast(wss, { type: 'getBlocksFrom', from: height - 10 < 0 ? 0 : height - 10 }); // simple
      }
      break;
    case 'getBlocksFrom':
      {
        const from = Math.max(0, msg.from|0);
        const slice = chain.slice(from);
        send(ws, { type: 'blocks', blocks: slice });
      }
      break;
    case 'blocks':
      if (Array.isArray(msg.blocks) && msg.blocks.length) {
        // naive adopt if strictly longer and hashes connect from genesis
        tryAdopt(msg.blocks);
      }
      break;
    case 'block':
      tryAddBlock(msg.block);
      break;
  }
}

function tryAdopt(remoteChain) {
  // Validate chain linkage quickly
  for (let i=1;i<remoteChain.length;i++) {
    if (remoteChain[i].prevHash !== remoteChain[i-1].hash) return;
  }
  if (remoteChain.length > chain.length) {
    chain = remoteChain;
    height = chain.length - 1;
    saveJSON(CHAIN_FILE, chain);
    log(`Adopted longer chain height=${height}`);
  }
}

function tryAddBlock(b) {
  const prev = chain[chain.length-1];
  const { ok, reason } = validateBlock(b, prev);
  if (!ok) return; // reject silently to reduce noise
  chain.push(b);
  height = chain.length - 1;
  saveJSON(CHAIN_FILE, chain);
  broadcast(wss, { type: 'tip', height, hash: b.hash });
  log(`Accepted block #${b.index} slot=${b.slot} by ${b.issuer}`);
}

// --- Slot loop ---
let slot = chain.length === 1 ? 1 : chain[chain.length-1].slot + 1;

function tick() {
  const prev = chain[chain.length-1];
  // Build proof for this slot
  const msg = Buffer.from(JSON.stringify({ slot, prevHash: prev.hash }));
  const proof = crypto.sign(null, msg, crypto.createPrivateKey(keys.privateKeyPem)).toString('hex');
  const elig = isEligible(proof, STAKE, TOTAL_STAKE, F_ACTIVE);
  const thrPct = Number(elig.thr) / Number(MAX256) * 100;

  if (elig.ok) {
    const b = forgeBlock({
      index: prev.index + 1,
      slot,
      prevHash: prev.hash,
      payload: { note: `Hello from ${NAME} at slot ${slot}` },
      issuer: NAME,
      privateKeyPem: keys.privateKeyPem,
      publicKeyPem: keys.publicKeyPem
    });
    tryAddBlock(b);
    broadcast(wss, { type: 'block', block: b });
    log(`FORGED block #${b.index} score ok (thr≈${thrPct.toFixed(6)}%)`);
  } else {
    // Occasionally share tip
    if (slot % 5 === 0) broadcast(wss, { type: 'tip', height, hash: prev.hash });
  }

  slot += 1;
  setTimeout(tick, SLOT_MS);
}

function log(msg) {
  const now = new Date().toISOString();
  console.log(`[${now}] [${NAME}@${PORT}] ${msg}`);
}

log(`Node started. stake=${STAKE}, f=${F_ACTIVE}, slotMs=${SLOT_MS}, peers=${PEERS.join(',')||'(none)'} `);
setTimeout(tick, SLOT_MS);
