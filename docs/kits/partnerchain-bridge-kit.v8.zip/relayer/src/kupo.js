// Kupo helpers (scaffold)
export async function utxosAt(kupoUrl, address) {
  const res = await fetch(`${kupoUrl}/v1/utxo/${address}`);
  if (!res.ok) throw new Error(`Kupo ${res.status}`);
  return res.json();
}
export async function findClaimUtxoByEventId(kupoUrl, scriptAddress, eventIdHex) {
  const utxos = await utxosAt(kupoUrl, scriptAddress);
  // TODO: decode inline datum and match event_id == eventIdHex.
  // For now, return the first UTxO (placeholder).
  return utxos[0] || null;
}
