import { getLucid, ClaimDatumCodec, EscrowDatumCodec } from "./lucid.js";
import { Data, toHex } from "lucid-cardano";
import { findClaimUtxoByEventId, utxosAt } from "./kupo.js";

const CLAIM_SCRIPT_ADDRESS_L1 = process.env.CLAIM_SCRIPT_ADDRESS_L1;
const CLAIM_SCRIPT_ADDRESS_L2 = process.env.CLAIM_SCRIPT_ADDRESS_L2;
const ESCROW_SCRIPT_ADDRESS_L1 = process.env.ESCROW_SCRIPT_ADDRESS_L1;
const ESCROW_SCRIPT_ADDRESS_L2 = process.env.ESCROW_SCRIPT_ADDRESS_L2;

function claimScript(tag){ return tag === "l1" ? CLAIM_SCRIPT_ADDRESS_L1 : CLAIM_SCRIPT_ADDRESS_L2; }
function escrowScript(tag){ return tag === "l1" ? ESCROW_SCRIPT_ADDRESS_L1 : ESCROW_SCRIPT_ADDRESS_L2; }

export async function submitClaimTx(chain, direction, event, claim, bonds) {
  const tag = chain === "l1" ? "l1" : "l2";
  const lucid = await getLucid(tag);
  const claimAddr = claimScript(tag);
  const escrowAddr = escrowScript(tag);
  if(!claimAddr || !escrowAddr) throw new Error("Missing CLAIM/ESCROW script addresses");

  const claimDatum = ClaimDatumCodec({
    event_id: toHex(Buffer.from(claim.event_id, "hex")),
    msg: toHex(Buffer.from(claim.msg, "hex")),
    agg_sig: toHex(Buffer.from(claim.agg_sig, "hex")),
    attesters_root: toHex(Buffer.from(claim.attesters_root, "hex")),
    threshold: BigInt(claim.threshold),
    created_at_time_ms: BigInt(claim.created_at_time_ms),
    window_ms: BigInt(claim.window_ms),
    challenged: false,
    claimer_pkh: toHex(Buffer.from(bonds.claimer_pkh, "hex")),
    claimer_bond_lovelace: BigInt(claim.claimer_bond_lovelace),
    challenger_bond_lovelace: BigInt(claim.challenger_bond_lovelace),
    version: 1n
  });

  const escrowDatum = EscrowDatumCodec({
    role: toHex(Buffer.from("CLAIMER_BOND")),
    claimer_pkh: toHex(Buffer.from(bonds.claimer_pkh, "hex")),
    challenger_pkh: toHex(Buffer.from(bonds.challenger_pkh || bonds.claimer_pkh, "hex")),
    event_id: toHex(Buffer.from(claim.event_id, "hex")),
    amount_lovelace: BigInt(claim.claimer_bond_lovelace),
    version: 1n
  });

  const tx = await lucid.newTx()
    .validFrom(claim.created_at_time_ms)
    .payToContract(claimAddr, { inline: claimDatum }, { lovelace: 2_000_000n })
    .payToContract(escrowAddr, { inline: escrowDatum }, { lovelace: BigInt(claim.claimer_bond_lovelace) })
    .complete();

  const signed = await tx.sign().complete();
  return await signed.submit();
}

export async function submitChallengeTx(chain, direction, ref, challenger) {
  const tag = chain === "l1" ? "l1" : "l2";
  const lucid = await getLucid(tag);
  const claimAddr = claimScript(tag);
  const escrowAddr = escrowScript(tag);
  const kupoUrl = process.env[tag.toUpperCase()+"_KUPO_URL"] || (tag === "l1" ? "http://localhost:1442" : "http://localhost:2442");

  // fetch current claim UTxO
  const claimUtxo = await findClaimUtxoByEventId(kupoUrl, claimAddr, ref.event_id);
  if(!claimUtxo) throw new Error("Claim UTxO not found");

  // re-output claim with challenged=true
  const newClaimDatum = ClaimDatumCodec({
    event_id: toHex(Buffer.from(ref.event_id, "hex")),
    msg: toHex(Buffer.from(ref.msg, "hex")),
    agg_sig: toHex(Buffer.from(ref.agg_sig || "", "hex")),
    attesters_root: toHex(Buffer.from(ref.attesters_root || "", "hex")),
    threshold: BigInt(ref.threshold || 0),
    created_at_time_ms: BigInt(ref.created_at_time_ms),
    window_ms: BigInt(ref.window_ms),
    challenged: true,
    claimer_pkh: toHex(Buffer.from(ref.claimer_pkh, "hex")),
    claimer_bond_lovelace: BigInt(ref.claimer_bond_lovelace),
    challenger_bond_lovelace: BigInt(ref.challenger_bond_lovelace),
    version: 1n
  });

  // challenger bond escrow
  const escDatum = EscrowDatumCodec({
    role: toHex(Buffer.from("CHALLENGER_BOND")),
    claimer_pkh: toHex(Buffer.from(ref.claimer_pkh, "hex")),
    challenger_pkh: toHex(Buffer.from(challenger.pkh, "hex")),
    event_id: toHex(Buffer.from(ref.event_id, "hex")),
    amount_lovelace: BigInt(ref.challenger_bond_lovelace),
    version: 1n
  });

  const tx = await lucid.newTx()
    .collectFrom([claimUtxo], Data.void()) // Challenge redeemer (placeholder)
    .validTo(ref.created_at_time_ms + ref.window_ms) // before deadline
    .payToContract(claimAddr, { inline: newClaimDatum }, { lovelace: 2_000_000n }) // re-output claim
    .payToContract(escrowAddr, { inline: escDatum }, { lovelace: BigInt(ref.challenger_bond_lovelace) })
    .complete();

  const signed = await tx.sign().complete();
  return await signed.submit();
}

export async function submitFinalizeTx(chain, direction, ref) {
  const tag = chain === "l1" ? "l1" : "l2";
  const lucid = await getLucid(tag);
  const claimAddr = claimScript(tag);
  const escrowAddr = escrowScript(tag);
  const kupoUrl = process.env[tag.toUpperCase()+"_KUPO_URL"] || (tag === "l1" ? "http://localhost:1442" : "http://localhost:2442");

  const claimUtxo = await findClaimUtxoByEventId(kupoUrl, claimAddr, ref.event_id);
  if(!claimUtxo) throw new Error("Claim UTxO not found");

  const escrowUtxos = await utxosAt(kupoUrl, escrowAddr);
  if(escrowUtxos.length === 0) throw new Error("Escrow UTxO not found");

  const tx = await lucid.newTx()
    .collectFrom([claimUtxo], Data.void())      // Finalize
    .collectFrom([escrowUtxos[0]], Data.void()) // Escrow Finalize -> refund claimer
    .validFrom(ref.created_at_time_ms + ref.window_ms) // after deadline
    .complete();

  const signed = await tx.sign().complete();
  return await signed.submit();
}
