# v8: Challenge path + reference-claim binding (scaffolds) + Lucid challenge submitter

## Aiken
- **Claim validator** (`aiken_optimistic_bonds_strict/validators/optimistic_bridge_bonds_strict.ak`):
  - Adds `Challenge` path that must:
    - occur **before** deadline,
    - re-output the claim at the same script with `challenged = true`,
    - include a **challenger bond** output (escrow recommended).
- **Escrow validator** (`aiken_bond_escrow/validators/escrow.ak`):
  - Now requires a **reference claim** (scaffold `has_reference_claim`) to match `event_id` when spending via `Finalize` or `ChallengeWin`.

## Lucid SDK
- `submitClaimTx`: unchanged from v7 (locks claimer bond at escrow).
- `submitChallengeTx`: spends the claim UTxO, **re-creates** it with `challenged=true`, and locks a **challenger bond** at escrow.
- `submitFinalizeTx`: collects claim + escrow UTxOs after the deadline and refunds the claimer.

## Kupo
- Helper functions to fetch UTxOs and (placeholder) find the claim by `event_id`.
  - Replace with precise datum-based filters (decode inline datum CBOR and compare `event_id`).

## Next
- Implement `has_reference_claim(...)` in Aiken (read reference inputs; check datum).
- Define exact **redeemer encodings** (Claim/Challenge/Finalize) to replace `Data.void()`.
- Add `ChallengeWin` flow that pays challenger and slashes claimer after on-chain/off-chain adjudication.
