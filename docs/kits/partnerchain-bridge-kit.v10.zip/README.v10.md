# v10: Real redeemers + inline-datum decoding (Kupo) + precise UTxO selection

## What changed
- **Concrete redeemer encodings** for both Claim and Escrow validators using Lucid `Constr`:
  - Claim: `Claim(claimer_pkh)`, `Challenge(challenger_pkh, reasonBytes)`, `Finalize()`
  - Escrow: `Finalize()`, `ChallengeWin()`
- **Kupo helpers** now decode inline datum CBOR and match on:
  - `ClaimDatum.event_id` for claim UTxOs, and
  - `EscrowDatum.role` + `event_id` for escrow UTxOs.
- **SDK functions** (`submitClaimTx`, `submitChallengeTx`, `submitFinalizeTx`, `submitChallengeWinTx`) now pass the correct redeemers and select exact UTxOs via Kupo.

## Wire-up notes
- Ensure your Kupo exposes inline datum CBOR in one of the recognized fields:
  - `inline_datum.cbor`, `datum.inline.cborHex`, or `datum.cbor`.
- Confirm your Aiken constructors’ **order** matches the `Constr` indices used here (0-based).
- Replace threshold/attester details and Lucid network tags to match your L1/L2 environment.
