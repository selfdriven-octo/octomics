import { ClaimDatumFrom, EscrowDatumFrom } from "./lucid.js";

export async function utxosAt(kupoUrl, address) {
  const res = await fetch(`${kupoUrl}/v1/utxo/${address}`);
  if (!res.ok) throw new Error(`Kupo ${res.status}`);
  return res.json();
}

// Attempt to read inline datum CBOR hex from Kupo UTxO JSON. We support a few common field names.
export function extractInlineDatumCbor(utxo) {
  // Common Kupo styles:
  // - utxo.inline_datum.cbor
  // - utxo.datum.inline.cborHex
  // - utxo.datum.cbor
  if (utxo?.inline_datum?.cbor) return utxo.inline_datum.cbor;
  if (utxo?.datum?.inline?.cborHex) return utxo.datum.inline.cborHex;
  if (utxo?.datum?.cbor) return utxo.datum.cbor;
  return null;
}

export async function findClaimUtxoByEventId(kupoUrl, address, eventIdHex) {
  const utxos = await utxosAt(kupoUrl, address);
  for (const u of utxos) {
    const cbor = extractInlineDatumCbor(u);
    if (!cbor) continue;
    try {
      const d = ClaimDatumFrom(cbor);
      // event_id inside datum is a hex-bytes string per Lucid Data encoding
      if (d.event_id?.toLowerCase?.() === eventIdHex.toLowerCase()) return u;
    } catch {}
  }
  return null;
}

export async function findEscrowUtxo(kupoUrl, address, roleStr, eventIdHex) {
  const utxos = await utxosAt(kupoUrl, address);
  for (const u of utxos) {
    const cbor = extractInlineDatumCbor(u);
    if (!cbor) continue;
    try {
      const d = EscrowDatumFrom(cbor);
      const roleHex = Buffer.from(roleStr, "utf8").toString("hex");
      if (d.role?.toLowerCase?.() === roleHex.toLowerCase() &&
          d.event_id?.toLowerCase?.() === eventIdHex.toLowerCase()) {
        return u;
      }
    } catch {}
  }
  return null;
}
