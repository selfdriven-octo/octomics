use blst::{min_pk as blst_core, BLST_ERROR};
use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Partial {
    pub pk_g1: String,
    pub sig_g2: String
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Aggregate {
    pub agg_sig_g2: String,
    pub agg_hash: String
}

pub fn aggregate(partials: &[Partial]) -> Result<Aggregate, String> {
    let mut agg = blst_core::AggregateSignature::new();
    let mut hasher = blake3::Hasher::new();
    for p in partials {
        let pk_bytes = hex::decode(&p.pk_g1).map_err(|e| e.to_string())?;
        let sig_bytes = hex::decode(&p.sig_g2).map_err(|e| e.to_string())?;
        let pk = blst_core::PublicKey::from_bytes(&pk_bytes).map_err(|_| "bad pk")?;
        let sig = blst_core::Signature::from_bytes(&sig_bytes).map_err(|_| "bad sig")?;
        let e = agg.add_signature(&sig, true, &pk, true);
        if e != BLST_ERROR::BLST_SUCCESS { return Err("aggregate failed".into()); }
        hasher.update(&pk_bytes);
        hasher.update(&sig_bytes);
    }
    let agg_sig = agg.to_signature();
    Ok(Aggregate {
        agg_sig_g2: hex::encode(agg_sig.to_bytes()),
        agg_hash: hex::encode(hasher.finalize().as_bytes())
    })
}
