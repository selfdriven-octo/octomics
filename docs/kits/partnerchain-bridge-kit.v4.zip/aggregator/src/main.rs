use clap::Parser;
use std::fs;
use partnerchain_aggregator::{Partial, aggregate};

#[derive(Parser, Debug)]
#[command(author, version, about)]
struct Args {
    #[arg(short, long)]
    input: Option<String>,
}

fn main() {
    let args = Args::parse();
    let data = if let Some(path) = args.input {
        fs::read_to_string(path).expect("read input file")
    } else {
        use std::io::Read;
        let mut s = String::new();
        std::io::stdin().read_to_string(&mut s).expect("read stdin");
        s
    };
    let partials: Vec<Partial> = serde_json::from_str(&data).expect("parse json");
    let agg = aggregate(&partials).expect("aggregate");
    println!("{}", serde_json::to_string_pretty(&agg).unwrap());
}
