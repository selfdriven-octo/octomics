# v4: Bonds + Aggregator CLI

- Aiken optimistic bridge with **claimer**/**challenger** bonds (scaffold): `aiken_optimistic_bonds/validators/optimistic_bridge_bonds.ak`
- Rust **BLS Aggregator CLI**: `aggregator/` reads JSON partials and prints aggregate JSON.

## Aggregator usage
```bash
cd aggregator
cargo run --release -- --input partials.json
# or
cat partials.json | cargo run --release --
```
